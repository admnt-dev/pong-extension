(() => {
  const cv = document.getElementById("c");
  const ctx = cv.getContext("2d");
  const W = cv.width, H = cv.height;
  const psEl = document.getElementById("ps"), asEl = document.getElementById("as");

  const PW = 8, PH = 58, PAD = 16, R = 6;
  const WIN = 7;
  const DIFF = {
    easy:   { speed: 190, err: 34, react: 0.55 },
    normal: { speed: 270, err: 18, react: 0.75 },
    hard:   { speed: 380, err: 6,  react: 0.92 },
  };
  let diff = "normal";

  const player = { y: H / 2 - PH / 2, score: 0 };
  const ai = { y: H / 2 - PH / 2, score: 0, target: H / 2, err: 0 };
  const ball = { x: W / 2, y: H / 2, vx: 0, vy: 0, speed: 0 };
  let state = "ready"; // ready | playing | paused | over
  let message = "Click or press Space to serve";
  let keys = {};
  let mouseY = null;
  let last = performance.now();
  let audio;

  function beep(freq, dur = 0.06) {
    try {
      audio = audio || new AudioContext();
      const o = audio.createOscillator(), g = audio.createGain();
      o.type = "square"; o.frequency.value = freq;
      g.gain.setValueAtTime(0.05, audio.currentTime);
      g.gain.exponentialRampToValueAtTime(0.0001, audio.currentTime + dur);
      o.connect(g); g.connect(audio.destination);
      o.start(); o.stop(audio.currentTime + dur);
    } catch (e) {}
  }

  function serve(dir) {
    ball.x = W / 2; ball.y = H / 2;
    ball.speed = 240;
    const a = (Math.random() * 0.7 - 0.35);
    ball.vx = Math.cos(a) * ball.speed * dir;
    ball.vy = Math.sin(a) * ball.speed;
    ai.err = (Math.random() * 2 - 1) * DIFF[diff].err;
  }

  function reset() {
    player.score = ai.score = 0;
    player.y = ai.y = H / 2 - PH / 2;
    ball.x = W / 2; ball.y = H / 2; ball.vx = ball.vy = 0;
    state = "ready"; message = "Click or press Space to serve";
    updateScore();
  }

  function updateScore() { psEl.textContent = player.score; asEl.textContent = ai.score; }

  function start() {
    if (state === "ready") { serve(Math.random() < 0.5 ? 1 : -1); state = "playing"; }
    else if (state === "paused") state = "playing";
    else if (state === "over") { reset(); }
  }

  function point(playerScored) {
    if (playerScored) player.score++; else ai.score++;
    updateScore();
    beep(playerScored ? 660 : 200, 0.18);
    if (player.score >= WIN || ai.score >= WIN) {
      state = "over";
      message = (player.score >= WIN ? "You win" : "You lose") + ". Click or Space to play again";
      ball.vx = ball.vy = 0;
    } else {
      state = "ready";
      message = "Click or press Space to serve";
      ball.x = W / 2; ball.y = H / 2; ball.vx = ball.vy = 0;
    }
  }

  function hitPaddle(py, dir) {
    const rel = (ball.y - (py + PH / 2)) / (PH / 2);      // -1 .. 1
    const clamped = Math.max(-1, Math.min(1, rel));
    ball.speed = Math.min(ball.speed * 1.06, 620);
    const angle = clamped * (Math.PI / 4);                 // max 45°
    ball.vx = Math.cos(angle) * ball.speed * dir;
    ball.vy = Math.sin(angle) * ball.speed;
    beep(dir > 0 ? 440 : 330);
  }

  function step(dt) {
    // player input
    const PS = 380;
    if (keys.w || keys.ArrowUp) player.y -= PS * dt;
    if (keys.s || keys.ArrowDown) player.y += PS * dt;
    if (mouseY !== null) player.y = mouseY - PH / 2;
    player.y = Math.max(0, Math.min(H - PH, player.y));

    // AI
    const d = DIFF[diff];
    if (state === "playing" && ball.vx > 0) {
      ai.target = ball.y + ai.err;
    } else {
      ai.target = H / 2;
    }
    const center = ai.y + PH / 2;
    const diffY = ai.target - center;
    const maxMove = d.speed * dt * (ball.vx > 0 ? 1 : 0.4);
    if (Math.abs(diffY) > 4) ai.y += Math.sign(diffY) * Math.min(Math.abs(diffY), maxMove);
    ai.y = Math.max(0, Math.min(H - PH, ai.y));

    if (state !== "playing") return;

    ball.x += ball.vx * dt;
    ball.y += ball.vy * dt;

    if (ball.y < R) { ball.y = R; ball.vy = Math.abs(ball.vy); beep(520, 0.03); }
    if (ball.y > H - R) { ball.y = H - R; ball.vy = -Math.abs(ball.vy); beep(520, 0.03); }

    // player paddle (left)
    if (ball.vx < 0 && ball.x - R <= PAD + PW && ball.x + R >= PAD &&
        ball.y >= player.y - R && ball.y <= player.y + PH + R) {
      ball.x = PAD + PW + R; hitPaddle(player.y, 1);
      ai.err = (Math.random() * 2 - 1) * d.err;
    }
    // ai paddle (right)
    if (ball.vx > 0 && ball.x + R >= W - PAD - PW && ball.x - R <= W - PAD &&
        ball.y >= ai.y - R && ball.y <= ai.y + PH + R) {
      ball.x = W - PAD - PW - R; hitPaddle(ai.y, -1);
    }

    if (ball.x < -R) point(false);
    else if (ball.x > W + R) point(true);
  }

  function rr(x, y, w, h, r) {
    ctx.beginPath(); ctx.roundRect(x, y, w, h, r); ctx.fill();
  }

  function draw() {
    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = "#fff";

    // center line
    for (let y = 12; y < H - 12; y += 22) rr(W / 2 - 1.5, y, 3, 12, 1.5);

    // paddles
    rr(PAD, player.y, PW, PH, PW / 2);
    rr(W - PAD - PW, ai.y, PW, PH, PW / 2);

    // ball
    ctx.beginPath(); ctx.arc(ball.x, ball.y, R, 0, Math.PI * 2); ctx.fill();

    // overlay message
    if (state !== "playing") {
      const text = state === "paused" ? "Paused. Space to resume" : message;
      ctx.font = "600 14px 'Segoe UI', system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      const w = ctx.measureText(text).width + 36, h = 34;
      ctx.fillStyle = "#fff";
      rr(W / 2 - w / 2, H / 2 + 34, w, h, h / 2);
      ctx.fillStyle = "#000";
      ctx.fillText(text, W / 2, H / 2 + 34 + h / 2 + 1);
    }
  }

  function loop(now) {
    const dt = Math.min((now - last) / 1000, 0.033);
    last = now;
    step(dt);
    draw();
    requestAnimationFrame(loop);
  }

  // input
  window.addEventListener("keydown", (e) => {
    if (e.key === " ") {
      e.preventDefault();
      if (state === "playing") state = "paused"; else start();
      return;
    }
    if (e.key === "r" || e.key === "R") { reset(); return; }
    const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    if (["w", "s", "ArrowUp", "ArrowDown"].includes(k)) { keys[k] = true; mouseY = null; e.preventDefault(); }
  });
  window.addEventListener("keyup", (e) => {
    const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    keys[k] = false;
  });
  cv.addEventListener("mousemove", (e) => {
    const r = cv.getBoundingClientRect();
    mouseY = (e.clientY - r.top) * (H / r.height);
  });
  cv.addEventListener("click", () => { if (state === "playing") return; start(); });

  document.querySelectorAll(".diff button").forEach((b) => {
    b.addEventListener("click", () => {
      diff = b.dataset.d;
      document.querySelectorAll(".diff button").forEach((x) => x.classList.toggle("on", x === b));
      b.blur();
      reset();
    });
  });

  updateScore();
  requestAnimationFrame(loop);
})();
